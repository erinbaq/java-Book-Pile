package pileofBooksInterface;

import java.util.*;

public class BookNodeDriver {
	public static void main(String[] args)
	{
		BookNode<String> myBooks = new BookNode<String>(); 
		Scanner kb= new Scanner(System.in);
		/**
		 * books prestacked
		 */
		System.out.println("I's going to stack 5 books! You can add or remove more if you want!");
		myBooks.add("book bottom");
		myBooks.add("middle3");
		myBooks.add("middle2");
		myBooks.add("middle1");
		myBooks.add("book top");
		/**
		 * show top book
		 */
		System.out.println("top is now: "+ myBooks.topBook());

		int x=1;
		
		/**
		 * user choice of what to do
		 */
		do
		{
		System.out.println("What do you want to do? \nremove(r), add(a), clear(c)or exit(e)?\n");
		String userChoice= kb.nextLine().toLowerCase();
		if(userChoice.equals("add")|| userChoice.contentEquals("a"))
		{
			System.out.println("what book?\n");
			String userBook= kb.nextLine();
			myBooks.add(userBook);
			System.out.println("top is now: \n"+ myBooks.topBook());
			x=1;
		}
		else if(userChoice.equals("remove")||userChoice.contentEquals("r"))
		{
			System.out.println("okay, top book removed!");
			myBooks.remove();
			System.out.println("top is now: \n"+ myBooks.topBook());
			x=1;
		}
		else if(userChoice.equals("clear")||userChoice.equals("c"))
		{
			System.out.println("okay! all books cleared!\n");
			myBooks.clear();
			x=1;
		}
		else if(userChoice.equals("exit")||userChoice.equals("e"))
		{
			System.out.print("thank you!");
			x++;
		}
		else
		{
			System.out.print("Sorry, I don't understand, try again\n");
		}
		}while(x==1);
		System.exit(1);
	}
}
