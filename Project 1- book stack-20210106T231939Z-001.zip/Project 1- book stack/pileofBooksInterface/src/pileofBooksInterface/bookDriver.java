package pileofBooksInterface;
import java.util.*;

public class bookDriver {

	public static void main(String[] args)
	{
		PileOfBooks<String> myBooks = new PileOfBooks<String>(); 
		Scanner kb= new Scanner(System.in);
		System.out.println("I's going to stack 5 books! You can add or remove more if you want!");
		myBooks.add("book bottom");
		myBooks.add("middle3");
		myBooks.add("middle2");
		myBooks.add("middle1");
		myBooks.add("book top");
		System.out.println("top is now: "+ myBooks.topBook());

		int x=1;
		
		do
		{
		System.out.println("What do you want to do? \nremove(r), add(a), clear(c)or exit(e)?");
		String userChoice= kb.nextLine().toLowerCase();
		if(userChoice.equals("add")|| userChoice.contentEquals("a"))
		{
			System.out.println("what book?");
			String userBook= kb.nextLine();
			myBooks.add(userBook);
			System.out.println("top is now: "+ myBooks.topBook());
			x=1;
		}
		else if(userChoice.equals("remove")||userChoice.contentEquals("r"))
		{
			System.out.println("okay, top book removed!");
			myBooks.remove();
			System.out.println("top is now: "+ myBooks.topBook());
			x=1;
		}
		else if(userChoice.equals("clear")||userChoice.equals("c"))
		{
			System.out.println("okay! all books cleared!");
			myBooks.clear();
			x=1;
		}
		else if(userChoice.equals("exit")||userChoice.equals("e"))
		{
			System.out.print("thank you!");
			x++;
		}
		else
		{
			System.out.print("Sorry, I don't understand, try again");
		}
		}while(x==1);
		System.exit(1);
	}
}