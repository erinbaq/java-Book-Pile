package pileofBooksInterface;
import java.util.*;

public class PileOfBooks<T> implements pileofBooksInterface<T> 
{
	private T[] bookPile;
	int top=0; //start empty
	private static final int maxi = 100; //default capacity
	private T[] bookStack;
	int bookCount;
	
	PileOfBooks()
	{
		T[] tempBookPile = (T[]) new Object[maxi];
		bookStack= tempBookPile;
		
	}
	
	/**
	 * add top book to stack
	 */
	public boolean add(T newBook)
	{
	    boolean result=true;
		++this.top;
		this.bookStack[this.top]=newBook;
		return result;
	}
	/** 
	 * remove top book from stack
	 */
	public T remove()
	{
        if(isEmpty())
        {
        	System.out.println("Empty already!");
        }
        int i = this.top;
        T str= bookStack[i];
        bookStack[i]=null;
        this.top--;
        return str;
	}
	
	/**
	 * check top bookof stack
	 */
	public T topBook()
	{
		if(isEmpty()) 
		{
			System.out.println("No books!");
		}	
		return this.bookStack[this.top];
		
	}
	/** 
	 * check if empty
	 */
	public boolean isEmpty()
	{
		return this.top==0; //true if top is null
	}
	/** 
	 * clear the stack
	 */
	public void clear()
	{
		while(!isEmpty())
			remove();
	}
	
	/**
	 * get size of stack
	 */
	public int size()
	{
		return bookStack.length;
	}


}