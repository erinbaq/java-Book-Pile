package pileofBooksInterface;

public interface pileofBooksInterface<T>
{
/**
 * add book to top	
 * @param newBook
 */
	boolean add(T newBook);

/**
 * remove book from top
 * @return
 */
	public T remove();

/**
 * top of the book
 * @return
 */
	T topBook();

/**
 * check if empty
 * @return
 */
	boolean isEmpty();

/**
 * clear
 */
	void clear();

/**
 * get size
 * @return
 */
	int size();

}