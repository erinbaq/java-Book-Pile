package pileofBooksInterface;

public class BookNode<T> implements pileofBooksInterface<T> 
{
	
	private Node bookPile;
	private int numberOfBooks;
	
	public BookNode()
	{
		bookPile = null;
		numberOfBooks=0;
	}
	
	private class Node
	{
		private T data;
		private Node next;
		
		private Node(T part)
		{
			this(part, null);
		}
		private Node(T part, Node nextNode)
		{
			data= part;
			next= nextNode;
		}
		
		private T getData()
		{
			return data;			
		}
		
		private Node getNextNode()
		{
			return next;			
		}
		
	}
	
	public boolean add(T newBook)
	{
		Node newNode = new Node(newBook);
		newNode.next=bookPile;
		bookPile=newNode;
		numberOfBooks++;
		return true;
		
	}
	
	public T remove()
	{
		T book=null;
		if(bookPile !=null)
		{
			book=bookPile.getData();
			bookPile = bookPile.getNextNode();
			numberOfBooks--;
		}
		return book;
	}
	
	public T topBook()
	{
		if(isEmpty())
		{
			System.out.print("no books!");
			System.exit(1);
		}	
		return bookPile.data;
	}
	
	public boolean isEmpty()
	{
		return numberOfBooks== 0;
	}
	
	public void clear()
	{
		while(!isEmpty())
			remove();
	}
	
	public int size()
	{
		return numberOfBooks;
	}
	
	public String toString()
	{
		String result= "";
		Node<T> temp = bookPile;
		while(temp != null)
		{
			result += temp.data +"\n";
			temp = temp.next;
		}
		return result;
	}
	
	
}
