module pileofBooksInterface {
}